<?php
$base = 10;
$altura = 8;

$area = ($base * $altura) / 2;
echo "Base: " . $base . " unidades<br>";
echo "Altura: " . $altura . " unidades<br>";
echo "Área: " . $area . " unidades cuadradas";
?>