<?php
$numero1 = -15;
$numero2 = -7;

if ($numero1 > $numero2) {
    echo "El número " . $numero1 . " es el mayor";
} else {
    echo "El número " . $numero2 . " es el mayor";
}
?>
