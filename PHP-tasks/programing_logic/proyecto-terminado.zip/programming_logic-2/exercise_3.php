<?php
$numero1 = 15;
$numero2 = 4;

$suma = $numero1 + $numero2;
$resta = $numero1 - $numero2;
$multiplicacion = $numero1 * $numero2;
$division = $numero1 / $numero2;
$residuo = $numero1 % $numero2;
echo "Número 1: " . $numero1 . "<br>";
echo "Número 2: " . $numero2 . "<br>";
echo "Suma: " . $suma . "<br>";
echo "Resta: " . $resta . "<br>";
echo "Multiplicación: " . $multiplicacion . "<br>";
echo "División: " . $division . "<br>";
echo "Residuo: " . $residuo;
?>
